<?php

/* Google App Client Id */
define('CLIENT_ID', '110010844879-fnm3jj41ubdscggi5gd1e91g97c7oo5u.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'GGKUQaI5Xn__9akqRQ9ZU80g');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost/gcalendar/google-login.php');

?>